#include "getchbuffer.h"
#include <stdlib.h>
void clearBuffer(struct getchBuffer *b) 
{
	int i;
	b->index=0;
	for(i=0;i<16;i++)
	{
		b->buff[i]=0;
	}
}
int isQuitBuffer(struct getchBuffer *b)
{
	int i;
	
	for(i=0;i<b->index;i++)
	{
		if(b->buff[i]=='q')
		return 1;
	}
	return 0;
}

void readToBuffer(struct getchBuffer *b)
{
	timeout(1000);
	int c=getch(); //probuje czytac z klawiatury, jezeli bedzie czekal dluzej niz timeout to zwroci -1 i idzie dalej
	if(c>0)
	{
		if(c=='\n')
		{
				clearBuffer(b);
		}
		else
		{
		b->buff[b->index]=c;
		b->index++;
		b->buff[b->index]=0;
		}
	}
	
}
int isBufferReady(struct getchBuffer *b)
{
	int a;
	if(sscanf(b->buff,"%d %d %d %d %d",&a,&a,&a,&a,&a)==5)
	{
		
		return 1;
	}
	else
	return 0;
}


