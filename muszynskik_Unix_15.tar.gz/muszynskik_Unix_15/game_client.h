#include <stdio.h>
#include <stdlib.h>
#include "game.h"
#include "getchbuffer.h"

#ifndef GAME_CLIENT_H
#define GAME_CLIENT_H
void parseResponse(struct getchBuffer *buff,struct game *g,char* response,char *request);
#endif
