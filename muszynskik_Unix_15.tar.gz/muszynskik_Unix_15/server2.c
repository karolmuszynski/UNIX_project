#include <stdio.h>

#include <errno.h>

#include <stdlib.h>

#include <unistd.h>

#include <sys/types.h>

#include <sys/socket.h>

#include <netinet/in.h>

#include <netdb.h>
#include <string.h>

#include "game_server.h"

#define PORT    8888
#define ERROR(source) (perror(source),\
		     fprintf(stderr,"%s:%d\n",__FILE__,__LINE__),\
					     exit(EXIT_FAILURE))
					     
#define MAXMSG  512

 int

make_socket (uint16_t port)

{
	
  int sock;
  struct sockaddr_in name;

  sock = socket (PF_INET, SOCK_STREAM, 0); //Tworzymy socket

  if (sock < 0)

    {
		
     ERROR("SOCKET");
     
    }
//Nadajemy socketowi nazwe
  name.sin_family = AF_INET;

  name.sin_port = htons (port);

  name.sin_addr.s_addr = htonl (INADDR_ANY);

  if (bind (sock, (struct sockaddr *) &name, sizeof (name)) < 0) //Podlaczenie socketa pod konkretny port

    {

      ERROR("BIND");

    }

  return sock;

}

int read_from_client (int filedes,int *currentGame,struct game **g) 

{

  char client_message[MAXMSG];
  char response[2560];
  int nbytes;

  nbytes = read (filedes, client_message, MAXMSG);

  if (nbytes < 0) // Probuje czytac informacje od klienta

    {
      /* Read error. */
      
      ERROR("READ");
      
      return -1;
    }

  else if (nbytes == 0)

    /* End-of-file. */

    return -1;

  else

    {

     puts("client message");
        puts(client_message);
        printf("\n");
        //Odpowiadam klientowi w zaleznosci od otrzymanego requesta
        parseRequest(g,currentGame,client_message,response);
        write(filedes , response , strlen(response)+1);

      return 0;

    }

}

int main (void)

{

  int currentGame=0; //tworze gry
    struct game *g[100];
    int i;
    for (i=0;i<100;i++)
		g[i]=init_game();

     
  int sock;

  fd_set active_fd_set, read_fd_set;
 
  struct sockaddr_in clientname;

  socklen_t size;

  /* Tworze socket i ustawiam zeby akceptowal polaczenia */

  sock = make_socket (PORT);

  if (listen (sock, 1) < 0)

    {

      ERROR("LISTEN");

    }

  /* Initialize the set of active sockets. */

  FD_ZERO (&active_fd_set);

  FD_SET (sock, &active_fd_set);

  while (1)

    {

      /* Block until input arrives on one or more active sockets. */

      read_fd_set = active_fd_set;

      if (select (FD_SETSIZE, &read_fd_set, NULL, NULL, NULL) < 0)

        {

         ERROR("SELECT");

        }

      /* Service all the sockets with input pending. */

      for (i = 0; i < FD_SETSIZE; ++i) // Sprawdzam czy nie przekroczono maksymalnej liczby fd

        if (FD_ISSET (i, &read_fd_set)) //Sprawdzam czy fd nalezy do zbioru

          {

            if (i == sock) // Sprawdzam czy jest to socket glowny czy klienta

              {

                /* Connection request on main socket. */

                int new;

                size = sizeof (clientname);

                new = accept (sock,(struct sockaddr *) &clientname,&size); //Zaakceptowanie polaczenia

                if (new < 0)

                  {

                   ERROR("ACCEPT");

                  }

                

                FD_SET (new, &active_fd_set); //Dolaczenie nowego socketu do zbioru socketow

              }

            else

              {

                /* Data arriving on an already-connected socket. */

                if (read_from_client (i,&currentGame,g) < 0) //Probuje pobrac dane z klienta

                  {

                    close (i);

                    FD_CLR (i, &active_fd_set);

                  }

              }

          }

    }

}
