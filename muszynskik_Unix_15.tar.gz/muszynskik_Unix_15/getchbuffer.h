#ifndef GETCHBUFFER_H
#define GETCHBUFFER_H
#include <ncurses.h>
struct getchBuffer
{
	char buff[16];
	int index;
};

void readToBuffer(struct getchBuffer *b);
void clearBuffer(struct getchBuffer *b);
int isBufferReady(struct getchBuffer *b); //Sprawdza czy bufor posiada w sobie juz pelny rozkaz

int isQuitBuffer(struct getchBuffer *b); //Sprawdz czy bufor zawiera litere q (koniec gry)
#endif
