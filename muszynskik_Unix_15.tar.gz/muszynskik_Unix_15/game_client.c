#include "game_client.h"
#include "getchbuffer.h"
#include <ncurses.h>

//funkcja analizuje odpowiedz serwera wywoluje odpowiednia funkcje by gracz mogl zareagowac a nastepnie generuje odpowiedni request
void parseResponse(struct getchBuffer *buffor,struct game *g,char* response,char *request)
{
	clear();
		char command[16];
		sscanf(response,"%s",command); //wczytujemy instrukcje
		
		if(strcmp(command,"newboard")==0) //od serwera otrzymalismy plansze
		{			
			int ret=responseToBoard(g->players[g->playerNumber%10-1],response); //wczytywanie tablicy z przeslanego stringa 
			if(ret!=0)
			{
				if(ret>1)
					mvprintw(20,0,"TRAFIONY ZATOPIONY!!!\n");
				else
					mvprintw(20,0,"PUDLO!!!\n");
			}
			print_board(g->players[g->playerNumber%10-1]); //wypisujemy nowa plansze
			int fx,fy,tx,ty,mt;
			mvprintw(17,0,"Enter number (x,y)->(tx,ty) mt (enter q to disconnect)");

				mvprintw(18,0,"%s",buffor->buff); //
				readToBuffer(buffor);
				if(isQuitBuffer(buffor)) 
				{
						sprintf(request,"disconnect %d",g->playerNumber);
				}
				else
				{
					if(isBufferReady(buffor))
					{
						
						
						sscanf(buffor->buff,"%d %d %d %d %d",&fx,&fy,&tx,&ty,&mt); //prosimy gracza o nowy ruch
							moveInGameRequest(g,fx,fy,tx,ty,mt,g->playerNumber,request); //tworzymy odpowiedni request do serwera
							
						
						clearBuffer(buffor);
					}
					else
					{
						sprintf(request,"loadboard %d",g->playerNumber);
					}
				}
	
		}
		if(strcmp(command,"newgame")==0) //serwer nam mowi ze zaczela sie nowa gra
		{
			
			clear();
			sscanf(response,"%s %d",command,&g->playerNumber);
			sprintf(request,"loadboard %d",g->playerNumber);
		}
		if(strcmp(command,"waiting")==0) //serwer kaze nam czekac na nowa gre
		{
			mvprintw(0,0,"oczekiwanie na innych graczy");
			refresh();
			sscanf(response,"%s %d",command,&g->playerNumber);
			sprintf(request,"waiting %d",g->playerNumber);
			sleep(1);
		}
		if(strcmp(command,"creategame")==0) //powinnismy poprosic o stworzenie nowej gry
		{
			
			sprintf(request,"newgame");
		}
		if(strcmp(command,"status")==0) //otrzymujemy informacje o stanie gry
		{
			int status;
			sscanf(response,"%s %d",command,&status);
			if(status==1)
				mvprintw(8,8,"Przegrales koniec gry");
			if(status==2)
				mvprintw(8,8,"Zwyciestwo!!!!");
			sprintf(request,"newgame");
			refresh();
			sleep(3);
		}
		if(strcmp(command,"disconnected")==0)
		{
			mvprintw(8,8,"Rozlaczono");
			refresh();
			sleep(3);
		endwin();
			exit(1);
		}
		
	}

