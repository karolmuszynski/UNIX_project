
#include<stdio.h> //printf
#include<string.h>    //strlen
#include<sys/socket.h>    //socket
#include<arpa/inet.h> //inet_addr
#include<ncurses.h>

#include <unistd.h>
#include "getchbuffer.h"
#include "game_client.h"
#define ERROR(source) (perror(source),\
			endwin(),\
			fprintf(stderr,"%s:%d\n",__FILE__,__LINE__),\
					     exit(EXIT_FAILURE))
					     
int main(int argc , char *argv[])
{
	struct getchBuffer buff;
	
	clearBuffer(&buff);
	initscr();
	clear();
	if(argc!=2)
		{
			printf("podaj ip servera");
			return 1;
		}
    int sock;
    struct sockaddr_in server;
    struct game *g=init_game();
    char message[1000] , server_reply[2000];
     sprintf(server_reply,"creategame"); //Tworzymy sztuczna odpowiedz serwera na ktora klient reaguje stworzeniem nowej gry
        
    //Tworzymy socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        ERROR("SOCKET");
    }
         
    server.sin_addr.s_addr = inet_addr(argv[1]);
    server.sin_family = AF_INET;
    server.sin_port = htons( 8888 );

    //Laczymy sie z serwerem
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        ERROR("CONNECT");
       
    }
  
  
  while(1)
    {
		parseResponse(&buff,g,server_reply,message); // Przetwarzamy odpowiedz serwera
        
        //Wysylamy żadanie do serwera 
        if( send(sock , message , strlen(message)+1 , 0) < 0)
        {
            ERROR("SEND");
            
        }
        //Otrzymujemy odpowiedz z serwera
        if( recv(sock , server_reply , 2000 , 0) < 0)
        {
            ERROR("RECV");
            
        }        
    }

    close(sock);
    endwin();
    return 0;
}
